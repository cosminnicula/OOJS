$("#message-in").focus();$(document).keydown(function(a){13==a.keyCode&&$("#message-out").text("You have entered: "+$("#message-in").val())});
//@ sourceMappingURL=script.closure.js.map
